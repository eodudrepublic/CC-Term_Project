<template>
  <el-button type="primary">{{$t('m.Save')}}</el-button>
</template>
<script>
  export default{
    name: 'Save'
  }
</script>
